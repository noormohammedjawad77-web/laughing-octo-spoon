package com.stark.afk;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShardManager {
    private final AfkPlugin plugin;
    private final File file;
    private final Map<UUID, Long> data = new HashMap<>();

    public ShardManager(AfkPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shards.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        for (String key : cfg.getKeys(false)) {
            try { data.put(UUID.fromString(key), cfg.getLong(key)); } catch (IllegalArgumentException ignored) {}
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        data.forEach((k, v) -> cfg.set(k.toString(), v));
        try { cfg.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save shards.yml: " + e.getMessage()); }
    }

    public long get(UUID id) { return data.getOrDefault(id, 0L); }

    public void set(UUID id, long amount) { data.put(id, Math.max(0, amount)); }

    /** Adds shards and plays the level-up sound if the player is online. */
    public void give(OfflinePlayer target, long amount) {
        data.merge(target.getUniqueId(), amount, Long::sum);
        Player p = Bukkit.getPlayer(target.getUniqueId());
        if (p != null) p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }

    public boolean take(UUID id, long amount) {
        long cur = get(id);
        if (cur < amount) return false;
        data.put(id, cur - amount);
        return true;
    }
}
