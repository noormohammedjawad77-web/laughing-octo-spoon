package com.stark.afk;

import org.bukkit.Location;

/** Full-height region (all Y levels). */
public record Region(String name, String world, int minX, int maxX, int minZ, int maxZ) {
    public boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        int x = l.getBlockX(), z = l.getBlockZ();
        return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }
}
