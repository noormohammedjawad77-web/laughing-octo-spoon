package com.stark.afk;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ShopGui implements Listener {
    public enum Mode { BUY, REMOVE, SETPRICE }

    private static final int PER_PAGE = 36;      // slots 9..44
    private static final int PREV_SLOT = 45;
    private static final int NEXT_SLOT = 53;     // far right

    private static class Holder implements InventoryHolder {
        int page; Mode mode; long price; Inventory inv;
        @Override public @NotNull Inventory getInventory() { return inv; }
    }

    private final AfkPlugin plugin;

    public ShopGui(AfkPlugin plugin) { this.plugin = plugin; }

    public void open(Player p, int page, Mode mode, long price) {
        List<ShopManager.Entry> list = plugin.getShop().getEntries();
        int pages = Math.max(1, (int) Math.ceil(list.size() / (double) PER_PAGE));
        page = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder();
        h.page = page; h.mode = mode; h.price = price;
        long bal = plugin.getShards().get(p.getUniqueId());
        h.inv = Bukkit.createInventory(h, 54, plugin.mc("gui.title", "balance", String.valueOf(bal)));

        ItemStack glass = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 9; i++) { h.inv.setItem(i, glass); h.inv.setItem(45 + i, glass); }

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= list.size()) break;
            h.inv.setItem(9 + i, display(list.get(idx), mode));
        }
        if (page > 0) h.inv.setItem(PREV_SLOT, named(Material.ARROW, plugin.m("gui.previous-page")));
        if (page < pages - 1) h.inv.setItem(NEXT_SLOT, named(Material.ARROW, plugin.m("gui.next-page")));
        p.openInventory(h.inv);
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(AfkPlugin.c(name));
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack display(ShopManager.Entry e, Mode mode) {
        ItemStack d = e.item.clone();
        ItemMeta m = d.getItemMeta();
        List<Component> lore = m.lore() != null ? new ArrayList<>(m.lore()) : new ArrayList<>();
        lore.add(Component.empty());
        lore.add(plugin.mc("gui.price", "price", String.valueOf(e.price)));
        switch (mode) {
            case BUY -> lore.add(plugin.mc("gui.click-buy"));
            case REMOVE -> lore.add(plugin.mc("gui.click-remove"));
            case SETPRICE -> lore.add(plugin.mc("gui.click-setprice"));
        }
        m.lore(lore);
        d.setItemMeta(m);
        return d;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getSlot();
        if (slot == NEXT_SLOT && e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.ARROW) {
            open(p, h.page + 1, h.mode, h.price);
            return;
        }
        if (slot == PREV_SLOT && e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.ARROW) {
            open(p, h.page - 1, h.mode, h.price);
            return;
        }
        if (slot < 9 || slot > 44) return;

        List<ShopManager.Entry> list = plugin.getShop().getEntries();
        int idx = h.page * PER_PAGE + (slot - 9);
        if (idx >= list.size()) return;
        ShopManager.Entry entry = list.get(idx);

        switch (h.mode) {
            case REMOVE -> {
                list.remove(idx);
                plugin.getShop().save();
                plugin.send(p, "gui.removed");
                open(p, h.page, h.mode, h.price);
            }
            case SETPRICE -> {
                entry.price = h.price;
                plugin.getShop().save();
                plugin.send(p, "gui.price-set", "price", String.valueOf(h.price));
                open(p, h.page, h.mode, h.price);
            }
            case BUY -> buy(p, entry, h);
        }
    }

    private void buy(Player p, ShopManager.Entry entry, Holder h) {
        long bal = plugin.getShards().get(p.getUniqueId());
        if (bal < entry.price) {
            plugin.send(p, "gui.not-enough", "price", String.valueOf(entry.price));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        Inventory temp = Bukkit.createInventory(null, 36);
        temp.setContents(p.getInventory().getStorageContents().clone());
        if (!temp.addItem(entry.item.clone()).isEmpty()) {
            plugin.send(p, "gui.inventory-full");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        plugin.getShards().take(p.getUniqueId(), entry.price);
        p.getInventory().addItem(entry.item.clone());
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        plugin.send(p, "gui.purchased", "price", String.valueOf(entry.price));
        open(p, h.page, h.mode, h.price);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
